function menu_in(e){
	e.setAttribute("class","nav-item active");
}
function menu_out(e){
	e.setAttribute("class", "nav-item");
}